namespace Register
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }


    }
}