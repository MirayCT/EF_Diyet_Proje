﻿namespace _02Project.BusinessLogicLayer.Abstract
{
    public interface IManager
    {
    }
}
