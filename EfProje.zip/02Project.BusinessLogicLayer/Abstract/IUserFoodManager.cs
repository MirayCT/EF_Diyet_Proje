﻿using _04Project.ViewModel.Concrete;
using _05Project.DataTransferObject.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02Project.BusinessLogicLayer.Abstract
{
    public interface IUserFoodManager : IGenericManager<UserFoodViewModel, UserFoodDto>
    {

    }
}
