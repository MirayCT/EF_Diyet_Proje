﻿using _02Project.BusinessLogicLayer.Abstract;
using _03Project.DataAccessLayer.Service.Concrete;
using _04Project.ViewModel.Concrete;
using _05Project.DataTransferObject.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02Project.BusinessLogicLayer.Concrete
{
    public class UserFoodManager : GenericManager<UserFoodService, UserFoodViewModel, UserFoodDto>, IUserFoodManager
    {
    }
}
