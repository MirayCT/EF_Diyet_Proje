﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForm_UI
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void btnAdminWeeklyReport_Click(object sender, EventArgs e)
        {
            if (Program.LoginedUserInformation is null || !Program.LoginedUserInformation.IsAdmin)
            {
                MessageBox.Show("Yetkiniz Yok!");
                new AdminLogin().Show();
                this.Hide();
                return;
            }
            WeeklyReport weeklyReport = new WeeklyReport();
            weeklyReport.Show();
            this.Hide();
        }

        private void btnAdminMonthlyReport_Click(object sender, EventArgs e)
        {
            if (Program.LoginedUserInformation is null || !Program.LoginedUserInformation.IsAdmin)
            {
                MessageBox.Show("Yetkiniz Yok!");
                new AdminLogin().Show();
                this.Hide();
                return;
            }
            MonthlyReport monthlyReport = new MonthlyReport();
            monthlyReport.Show();
            this.Hide();
        }

        private void btnAdminTopFoods_Click(object sender, EventArgs e)
        {
            if (Program.LoginedUserInformation is null || !Program.LoginedUserInformation.IsAdmin)
            {
                MessageBox.Show("Yetkiniz Yok!");
                new AdminLogin().Show();
                this.Hide();
                return;
            }
            TopFoods topFoods = new TopFoods();
            topFoods.Show();
            this.Hide();
        }

    }
}
