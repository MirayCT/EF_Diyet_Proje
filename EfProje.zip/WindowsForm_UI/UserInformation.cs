﻿using _04Project.ViewModel.Concrete;
using _06Project.Entities.Concrete;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using User = _06Project.Entities.Concrete.User;

namespace WindowsForm_UI
{
    public partial class UserInformation : Form
    {
        public UserInformation()
        {
            InitializeComponent();
        }

        private void btnUserStartLoginFood_Click(object sender, EventArgs e)
        {
            UserFoodLog userFoodLog = new UserFoodLog();
            userFoodLog.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserViewModel userViewModel = new UserViewModel();
            txtbUserAge.Text = userViewModel.Age.ToString();
            txtbUserHeight.Text = userViewModel.Height.ToString();
            txtbUserWeight.Text = userViewModel.Weight.ToString();
            txtbUserGoalWeight.Text = userViewModel.GoalWeight.ToString();
        }
    }
}
