﻿using _02Project.BusinessLogicLayer.Concrete;
using _03Project.DataAccessLayer.Context.EF;
using _06Project.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForm_UI
{
    public partial class UserFoodLog : Form
    {
        private readonly EfDbContext _db;
        Food food = new Food();
        private FoodManager foodManager;
        private MealTimeManager mealTimeManager;
        private PortionSizeManager portionSizeManager;
        public UserFoodLog()
        {
            InitializeComponent();
            foodManager = new FoodManager();
            cmbUserSelectedFood.DataSource = foodManager.GetAll().Data;

            mealTimeManager = new MealTimeManager();
            cmbUserSelectedMealTime.DataSource = mealTimeManager.GetAll().Data;

            portionSizeManager = new PortionSizeManager();
            cmbUserSelectedPortionSize.DataSource = portionSizeManager.GetAll().Data;

            _db = new EfDbContext();


        }

        private void btnShowFoodPicture_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {


                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;
                    byte[] imageData = File.ReadAllBytes(filePath);

                    food.Picture = imageData;
                    _db.Foods.Add(food);
                    _db.SaveChanges();

                }

            }
            if (food.Picture != null)
            {
                using (MemoryStream ms = new MemoryStream(food.Picture))
                {
                    pbFoodPics.SizeMode = PictureBoxSizeMode.Zoom;
                    pbFoodPics.Image = Image.FromStream(ms);
                }
            }
        }

        private void btnUserAddMeal_Click(object sender, EventArgs e)
        {
            
        }
    }
}
