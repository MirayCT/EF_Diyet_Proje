﻿namespace _06Project.Entities.Common
{
    public enum DataStatus
    {
        Inserted = 1,
        Updated = 2,
        Deleted = 3        
    }
}
