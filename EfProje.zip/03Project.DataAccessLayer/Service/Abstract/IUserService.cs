﻿using _05Project.DataTransferObject.Concrete;

namespace _03Project.DataAccessLayer.Service.Abstract
{
    public interface IUserService : IGenericService<UserDto>
    {
    }
}
