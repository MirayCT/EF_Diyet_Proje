﻿using _03Project.DataAccessLayer.Context.EF;
using _03Project.DataAccessLayer.Repository.Abstract;
using _06Project.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03Project.DataAccessLayer.Repository.Concrete
{
    public class UserFoodRepository : GenericRepository<UserFood>, IUserFoodRepository
    {
        public UserFoodRepository() : base(new EfDbContext())
        {
            
        }
    }
}
