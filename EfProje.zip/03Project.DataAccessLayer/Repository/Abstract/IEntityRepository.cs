﻿namespace _03Project.DataAccessLayer.Repository.Abstract
{
    public interface IEntityRepository
    {

    }
}
