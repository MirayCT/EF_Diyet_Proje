﻿using _03Project.DataAccessLayer.Constants;
using _03Project.DataAccessLayer.Context.Abstract;
using _03Project.DataAccessLayer.Context.EF;
using _03Project.DataAccessLayer.UnitOfWorks;
using _05Project.DataTransferObject.Abstract;
using _06Project.Entities.Abstract;
using _06Project.Entities.Common;
using _06Project.Entities.Concrete;
using _08Project.Mapper;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace _03Project.DataAccessLayer.Repository.Abstract
{
    public class GenericRepository<TEntity> : IGenericRepository<TEntity>
        where TEntity : class, IEntity,new()
    {
        DbContext _dbContext;
        DbSet<TEntity> _dbSet;
        
        public GenericRepository(DbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet =_dbContext.Set<TEntity>();
        }

        public void Add(TEntity entity)
        {
            entity.DataStatus = DataStatus.Inserted;
            entity.Created = DateTime.Now;
            _dbSet.Add(entity);
            _dbContext.SaveChanges();
        }
        public void Update(TEntity entity)
        {
            entity.DataStatus = DataStatus.Updated;
            _dbSet.Update(entity);
            _dbContext.SaveChanges();
        }
        public void Delete(TEntity entity)
        {
            entity.Deleted=DateTime.Now;
            entity.DataStatus = DataStatus.Deleted;
            Update(entity);
            _dbContext.SaveChanges();
        }
        public void Remove(TEntity entity)
        {
            entity.DataStatus = DataStatus.Deleted;
            entity.Deleted = DateTime.Now;
            _dbSet.Remove(entity);
            _dbContext.SaveChanges();
        }

        public ICollection<TEntity> GetAll()
        {
            try
            {
                var entities = _dbSet.ToList();

                return entities;
            }
            catch (ArgumentException)
            {

                throw new Exception(Messages.ArgumentIsNull);
            }
            
        }

        public TEntity GetById(int id)
        {

            var entity = _dbSet.Find(id);

            if (entity == null)
                throw new Exception(Messages.IdNotFound);

            return entity;
        }
              
        public ICollection<TEntity> Search(Expression<Func<TEntity, bool>> predicate)
        {
            try
            {
                var entities = _dbSet.Where(predicate).ToList();
                return entities;
            }
            catch (ArgumentNullException)
            {

                throw new Exception(Messages.ConditionalArgumentIsNull);
            }
        }
         ~GenericRepository()
        {
            _dbContext.Dispose();
        }
    }
}
