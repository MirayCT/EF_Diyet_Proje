﻿using _05Project.DataTransferObject.Concrete;
using _06Project.Entities.Concrete;

namespace _03Project.DataAccessLayer.Repository.Abstract
{
    public interface IMealTimeRepository : IGenericRepository< MealTime>
    {

    }
}
