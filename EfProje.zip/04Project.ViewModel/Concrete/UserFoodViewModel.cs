﻿using _04Project.ViewModel.Abstract;
using _06Project.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04Project.ViewModel.Concrete
{
    public class UserFoodViewModel : IViewModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int FoodId { get; set; }
        public int PortionSizeId { get; set; }
        public int MealTimeId { get; set; }
        public DateTime Time { get; set; }
        public MealTime MealTime { get; set; }
        public User User { get; set; }
        public Food Food { get; set; }
        public PortionSize PortionSize { get; set; }
    }
}
